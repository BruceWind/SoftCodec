#include "fdkaac/include/fdk-aac/aacenc_lib.h"
#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <jni.h>
#include "xiecc_rtmp.h"

jint Java_com_example_softencode_AudioRecorde_initAAC(JNIEnv* env,jobject thiz, jint bitrate,jint samplerate,jint channels);

jint Java_com_example_softencode_AudioRecorde_Encode(JNIEnv* env,jobject thiz,jbyteArray data,jint data_len,jint time);
